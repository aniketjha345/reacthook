// import { motion } from 'framer-motion'; // Removed as it's unused
import styled from 'styled-components';
import ProjectCard from '../components/ProjectCard'; // Assuming you have this

const ProjectsPageContainer = styled.div`
  padding: 6rem 2rem 2rem;
  background: ${({ theme }) => theme.background};
  min-height: 100vh;
`;

const ProjectsPage = () => {
  return (
    <ProjectsPageContainer>
      {/* Projects component content */}
    </ProjectsPageContainer>
  );
};

export default ProjectsPage;