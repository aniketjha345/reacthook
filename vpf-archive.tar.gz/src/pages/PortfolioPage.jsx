// import { motion } from 'framer-motion'; // Removed as it's unused
import styled from 'styled-components';
import PortfolioGrid from '../components/PortfolioGrid';

const PortfolioPageContainer = styled.div`
  padding: 6rem 2rem 2rem; /* Adjust top padding for fixed navbar */
  background: ${({ theme }) => theme.background};
  min-height: 100vh;
`;

const Title = styled.h1`
  // Add any necessary styles for the title
`;

const PortfolioPage = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <PortfolioGrid />
    </motion.div>
  );
};

export default PortfolioPage;